var express = require('express');
var request = require('request');
var Twitter = require('twitter');
var app = express()

var client = new Twitter({
  consumer_key: 'wXVhf49uHzf2yiD8sKyJfBofn',
  consumer_secret: 'NBEEbrzZ2Y6FpNKVK7fsEHqjWiCrwNrWUD3KHcdeaWmq1uCJGE',
  access_token_key: '2193262517-ORAtKTnH6FLGog6S2gbUKrmUmglVcfUQlLt8jrL',
  access_token_secret: 'fQBTq284XRCk2lBuG1p1kwmantRZtvkgMSSj2DCumpcxq'
});


var words = {great:2, gr8:2, good:1, best:1, love:2, like:1, ':-)':2, terrible: -2, bad:-1, hate:-2, h8:-2, ':-(':-2}


app.get('/sentiment', function(req, resp){
  var inputString = req.query.text;
  if (inputString == undefined)
  {
	  resp.json({error:'No string provided'});
	  return;
  }
  //console.log(inputString.length);
/*   inputString = inputString.split(' ');
  
  var totalSentiment = 0;
  console.log('here1')
  for (i=0; i<inputString.length; i++)
	{
	  individualWord = inputString[i]
	  if (words[individualWord] != undefined)
		{
		  totalSentiment += words[individualWord];
		}
	}
	console.log('here2') */
	
	totalSentiment = sentimentAnalyse(inputString);
	resp.json({senitment:totalSentiment});
})

//index.js
// 1.) make a request to faqs.php requesting the usual stuff
app.get('/', function(req, resp){
	var topic = req.query.topic;
	var text = req.query.text;
	var retValue = {}
	
	request.get('http://community.dur.ac.uk/joseph.a.cass/faq2016/faqs.php',{'qs':{'topic':topic, 'q':text}}, function (error, response, body) {
		if (!error && response.statusCode == 200) {
			//console.log(body);
			//console.log(topic);
			//resp.json(JSON.parse(body));
			retValue.faqs = JSON.parse(body).faqs;
			//console.log(retValue);
			//resp.json(retValue);
			
			//console.log("here1");
			// Twitter
			//console.log(text.length);
			
			if (text.length == 0)
			{
				resp.json(retValue);			
			}
			
			else
			{
				client.get('search/tweets', {q: text}, function(error, tweets, response) {

					//console.log("here2");
					
					//console.log(tweets.statuses);
					statuses = tweets.statuses;
					if (tweets.statuses == undefined)
					{
						resp.json(retValue);
						return;
					}
					
					allTweets = [];
					//console.log(statuses.length);
					for (var i=0; i<statuses.length; i++)
						{
							//console.log(i);
							//console.log("here3");
							
							individualTweet = statuses[i]['text'];


							console.log(individualTweet);

							tweetID = statuses[i]['id'];
							tweetSentiment = sentimentAnalyse(individualTweet);
							thisTweet = [individualTweet,tweetID,tweetSentiment];
							//console.log(thisTweet);
							//console.log(thisTweet[1]);
							allTweets.push(thisTweet);
							
							//feed to sentiment and get sentiment value
							//store value for each tweet
							//add individual tweet to array 'allTweets'
							//sort arrray by sentiment- way to do this
							//choose 3 best and 3 worst
						}
					
					allTweets.sort(function(a,b){
						return a[2] - b[2];
					});
					//console.log(allTweets)
					
					//positive tweets:
					
					positiveTweets = []
					for (var j=allTweets.length-1; j>=allTweets.length-3; j--)
					{
						var thisTweet = allTweets[j];
						var tweetDetails = {text:thisTweet[0],id:thisTweet[1], sentiment:thisTweet[2]};	
						positiveTweets.push(tweetDetails);
					}
					
					//negative tweets:
					
					negativeTweets = []
					for (var k=0; k<3; k++)
					{
						var thisTweet = allTweets[k];
						var tweetDetails = {text:thisTweet[0],id:thisTweet[1], sentiment:thisTweet[2]};	
						negativeTweets.push(tweetDetails);
					}
					
					retValue.tweets = {}
					retValue.tweets.positive = positiveTweets;
					retValue.tweets.negative = negativeTweets;
					console.log(retValue);
					//console.log(retValue.tweets.positive[1]);
					resp.json(retValue);
				});
				
				
				
				
			}
		}
	})	
})

function sentimentAnalyse(tweetText)
{
tweetText = tweetText.replace(/[.,#!&-]/g,""); //from: http://stackoverflow.com/questions/4328500/how-can-i-strip-all-punctuation-from-a-string-in-javascript-using-regex
tweetText = tweetText.replace(/\s{2,}/g," ");
  tweetText = tweetText.split(' ');
  console.log(tweetText);
  
  
  var totalSentiment = 0;
  //console.log('sentAnalysis');
  for (var i=0; i<tweetText.length; i++)
	{
	  individualWord = tweetText[i].toLowerCase();
	  //console.log(individualWord);
	  if (words[individualWord] != undefined)
		{
		  totalSentiment += words[individualWord];
		  //console.log("adding sentiment");
		}
	}
	return totalSentiment;
}

// 2.) make a request to the Twitter API with just the search query as a param
//-look for twitter package. google 'node twitter' use search/tweets in url 
//-pass q:text as a parameter NOT WITH QS.

// 3.) send each Tweet to the sentiment analysis
//-use request.get again but use /sentiment as url
//-pass qs this time but with text being the tweet
//dont need topic
//create an object for each tweet which is stored in an array like this:'{senitment:returned value, tweet:text from tweet}'

// 4.) sort Tweets by sentiment: 3 best and 3 worst 
//sort the array (google it) and grab best and worst 3

// 5.) put Tweets and faqs together and send to index.html


//HTML
// 6.) use the data in html and make look pretty

app.use(express.static('public'))

app.listen(8080)



