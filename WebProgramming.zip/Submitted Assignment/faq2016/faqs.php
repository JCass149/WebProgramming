<?php
header('Content-type: application/json');
//echo $_SERVER[REQUEST_METHOD];



if ($_SERVER[REQUEST_METHOD] == "GET")
{
	//INITIALISATION
	$faqs = file_get_contents('data.json');
	$json = json_decode($faqs, true);
	$topicID = $_GET['topic']; 				//SUPER GLOBAL VARIABLE
	$filterString = $_GET['q']; 			//SUPER GLOBAL VARIABLE


	
	//MANIPULATION
	$faqs = $json['faqs'];

	$result = array();
	
	$filterString = strtolower(preg_replace("#[[:punct:]]#", "", $filterString)); //remove punctuation
	$arrayOfString = explode(" ", $filterString);					  //create array of search words
	

	
	$wordlist = array("I","a","about","an", "and","are","as","at","be","by","com"
	,"for","from","how","in","is","it","of","on","or","that","the","this"
	,"to","was","what","when","where","who","will","with","the"); // LIST FROM www.ranks.nl/stopwords


	foreach ($wordlist as &$word) {
		$word = '/\b' . preg_quote($word, '/') . '\b/';
	}
	
	$strippedString = preg_replace($wordlist, '', $arrayOfString);

	
	for ($x = 0; $x < sizeof($faqs); $x++) { 	//FOR EACH FAQ
		if ($faqs[$x]['topic index'] == $topicID){

			if ($filterString == '')				//IF NO WORD WAS INPUT
			{
					$to_add = array();
					$to_add['question'] = $faqs[$x]['question'];
					$to_add['answer'] = $faqs[$x]['answer'];
					$result[] = $to_add;
			}
		
			else
			{
				$isWordPresent = false;		
				
				
				//var_dump($strippedString);
				

				
				for ($i = 0; $i < sizeof($strippedString); $i++) {
					if(strlen($strippedString[$i]) > 0){ //ignores empty strings			
						if (strpos($faqs[$x]['question'], $strippedString[$i]) !== false) { //compares words against questions
							$isWordPresent = true;
						}
						if (strpos($faqs[$x]['answer'], $strippedString[$i]) !== false) { //compares words against answers
							$isWordPresent = true;
						}
					}
				}

				if ($isWordPresent == true){
					$to_add = array();
					$to_add['question'] = $faqs[$x]['question'];
					$to_add['answer'] = $faqs[$x]['answer'];
					$result[] = $to_add;
				}
			}
		}
	}
	
	$final = array();			//FORMATS IT THE WAY STEVE WANTS
	$final['faqs'] = $result;

	//FINALISATION
	$encoded = json_encode($final);
	echo $encoded;
}


else if ($_SERVER[REQUEST_METHOD] == "POST")
{
	//CREATE HASH
	$authToken = $_POST['auth_token'];	
	$encodedString = 'faq2016 '. date("Y-m-d") . ' '. $_SERVER['REMOTE_ADDR'];
	$encodedString = hash ( 'sha256' , $encodedString );
	
	if ($authToken === "concertina" || $authToken === $encodedString)
	{
		//INITIALISATION
		$topicIndex = $_POST['topic']; 					//SUPER GLOBAL VARIABLE
		$questionToAdd = $_POST['question']; 			//SUPER GLOBAL VARIABLE
		$answerToAdd = $_POST['answer']; 				//SUPER GLOBAL VARIABLE
		$authToken = $_POST['auth_token'];				//SUPER GLOBAL VARIABLE

		$faqs = file_get_contents('data.json');
		$json = json_decode($faqs, true);
		$numberOfTopics = sizeof($json['topics']);
		
		
		//MANIPULATION
		if ($topicIndex == "" || $questionToAdd == "" || $answerToAdd == "")
		{
			$errorStatement = array();
			$errorStatement['error'] = "you can't add an empty value";
			$encoded = json_encode($errorStatement);
			echo $encoded;
		}
		
		else if(is_numeric($topicIndex) == false)
		{
			$errorStatement = array();
			$errorStatement['error'] = "the topic index must be an integer";
			$encoded = json_encode($errorStatement);
			echo $encoded;
		}

		else if($topicIndex >= $numberOfTopics || $topicIndex < 0)
		{
			$errorStatement = array();
			$errorStatement['error'] = "that topic index is not valid";
			$encoded = json_encode($errorStatement);
			echo $encoded;
		}
		
		
		else{
			$inp = file_get_contents('data.json');	//example from www.stackoverflow.com/questions/7895335/append-data-to-a-json-file-with-php

			$tempArray = json_decode($inp,true);
			$FAQtoAdd = array("question" => $questionToAdd,"answer" => $answerToAdd,"topic index" => $topicIndex);
			array_push($tempArray['faqs'], $FAQtoAdd);		
			$jsonData = json_encode($tempArray);
			file_put_contents('data.json', $jsonData);
			
		//FINALISATION
			
			$successStatement = array();
			$successStatement['success'] = "the topic was succesfully added";
			$encoded = json_encode($successStatement);
			echo $encoded;
		}
		
	}
	else{
		$errorStatement = array();
		$errorStatement['error'] = "you do not have authorisation you big silly";
		$encoded = json_encode($errorStatement);
		echo $encoded;
	}
}


//}

//echo '<pre>' . print_r($json, true) . '</pre>';
//var_dump($final);
?>