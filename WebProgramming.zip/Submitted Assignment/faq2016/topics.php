<?php
header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
//echo $_SERVER[REQUEST_METHOD];

if ($_SERVER[REQUEST_METHOD] == "GET")
{
	//INITIALISATION
	$topics = file_get_contents('data.json');
	$json = json_decode($topics, true);

	//MANIPULATION
	$topics = $json['topics'];
	$data["topics"] = $topics;

	//FINALISATION
	$encoded = json_encode($data);
	echo $encoded;
}

else if($_SERVER[REQUEST_METHOD] == "POST")
{
	//CREATE HASH
	$authToken = $_POST['auth_token'];	
	$encodedString = 'faq2016 '. date("Y-m-d") . ' '. $_SERVER['REMOTE_ADDR'];
	$encodedString = hash ( 'sha256' , $encodedString );
	
	if ($authToken === "concertina" || $authToken === $encodedString)
	{

		//INITIALISATION
		$topicName = $_POST['topic']; 				//SUPER GLOBAL VARIABLE
		$authToken = $_POST['auth_token']; 			//SUPER GLOBAL VARIABLE
		
		
		//MANIPULATION
		if ($topicName == "")
		{
			$errorStatement = array();
			$errorStatement['error'] = "you can't add an empty string";
			$encoded = json_encode($errorStatement);
			echo $encoded;
		}
		
		//MORE DATA VALIDATION CHECKS HERE
		
		else{
			$inp = file_get_contents('data.json');	//example from www.stackoverflow.com/questions/7895335/append-data-to-a-json-file-with-php
			$tempArray = json_decode($inp,true);
			array_push($tempArray['topics'], $topicName);
			$jsonData = json_encode($tempArray);
			file_put_contents('data.json', $jsonData);
		
		//FINALISATION
		
			$successStatement = array();
			$successStatement['success'] = "the topic was succesfully added";
			$encoded = json_encode($successStatement);
			echo $encoded;
		}
	}
	else{
		$errorStatement = array();
		$errorStatement['error'] = "you do not have authorisation you big silly";
		$encoded = json_encode($errorStatement);
		echo $encoded;
		
	}
	
	//FINALISATION
}

//echo '<pre>' . print_r($encoded, true) . '</pre>';

?>